<!DOCTYPE html>
<html>
<head>
	<title>Edit Data Pegawai</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>
<body>
	<div class="container">
		<div class="card">
			<div class="card-body">

				<style type="text/css">
					.pagination li{
					float: left;
					list-style-type: none;
					margin:5px;
					}
				</style>

			<h3>Edit Data Pegawai</h3>

			</div>

			<a href="/datapegawai"> Kembali</a>
	
			<br/>
			<br/>
			<table class="table table-bordered table-striped table-hover">
			<?php $__currentLoopData = $datapegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<form action="/datapegawai/update" method="post">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="id" value="<?php echo e($p->id); ?>"> <br/>
				NIP <input type="number" required="required" name="nip" value="<?php echo e($p->nip); ?>"> <br/>
        		Nama <input type="text" required="required" name="namapegawai" value="<?php echo e($p->namapegawai); ?>"> <br/>
        		Tempat Lahir <input type="text" required="required" name="tempatlahir" value="<?php echo e($p->tempatlahir); ?>"> <br/>
        		Alamat <textarea required="required" name="alamat"><?php echo e($p->alamat); ?></textarea> <br/>
				Tanggal Lahir <input type="date" required="required" name="tanggallahir" value="<?php echo e($p->tanggallahir); ?>"> <br/>
        		Jenis Kelamin <input type="text" required="required" name="jeniskelamin" value="<?php echo e($p->jeniskelamin); ?>"> <br/>
        		Jabatan <input type="text" required="required" name="jabatan" value="<?php echo e($p->jabatan); ?>"> <br/>
				<input type="submit" value="Simpan Data" onclick="return confirm('apakah anda yakin?')">
			</form>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
			<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
			<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
			<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
			</div>
		</div>
	
</body>
</html><?php /**PATH /opt/lampp/htdocs/DataPegawai/resources/views/edit.blade.php ENDPATH**/ ?>