<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class DataPegawaiController extends Controller
{
	public function index()
	{
    	// mengambil data dari table datapegawai
		$datapegawai = DB::table('datapegawai')->get();

    	// mengirim data datapegawai ke view index
		return view('index',['datapegawai' => $datapegawai]);

		// mengambil data dari table datapegawai
		$datapegawai = DB::table('datapegawai')->paginate(10);
 
    		// mengirim data datapegawai ke view index
		return view('index',['datapegawai' => $datapegawai]);

	}

	// method untuk menampilkan view form tambah datapegawai
	public function tambah()
	{

		// memanggil view tambah
		return view('tambah');

	}

	// method untuk insert data ke table datapegawai
	public function store(Request $request)
	{
		// insert data ke table datapegawai
		DB::table('datapegawai')->insert([
			'nip' => $request->nip,
			'namapegawai' => $request->namapegawai,
			'tempatlahir' => $request->tempatlahir,
            'alamat' => $request->alamat,
            'tanggallahir' => $request->tanggallahir,
            'jeniskelamin' => $request->jeniskelamin,
            'jabatan' => $request->jabatan
		]);
		// alihkan halaman ke halaman datapegawai
		return redirect('/datapegawai');

	}

	// method untuk edit data datapegawai
	public function edit($id)
	{
		// mengambil data datapegawai berdasarkan id yang dipilih
		$datapegawai = DB::table('datapegawai')->where('id',$id)->get();
		// passing data datapegawai yang didapat ke view edit.blade.php
		return view('edit',['datapegawai' => $datapegawai]);

	}

	// update data datapegawai
	public function update(Request $request)
	{
		// update data datapegawai
		DB::table('datapegawai')->where('id',$request->id)->update([
			'nip' => $request->nip,
			'namapegawai' => $request->namapegawai,
			'tempatlahir' => $request->tempatlahir,
            'alamat' => $request->alamat,
            'tanggallahir' => $request->tanggallahir,
            'jeniskelamin' => $request->jeniskelamin,
            'jabatan' => $request->jabatan
		]);
		// alihkan halaman ke halaman datapegawai
		return redirect('/datapegawai');
	}

	// method untuk hapus data datapegawai
	public function hapus($id)
	{
		// menghapus data datapegawai berdasarkan id yang dipilih
		DB::table('datapegawai')->where('id',$id)->delete();
		
		// alihkan halaman ke halaman datapegawai
		return redirect('/datapegawai');
	}

	public function cari(Request $request)
	{
		// menangkap data pencarian
		$cari = $request->cari;
 
    		// mengambil data dari table datapegawai sesuai pencarian data
		$datapegawai = DB::table('datapegawai')
		->where('namapegawai','like',"%".$cari."%")
		->paginate();
 
    		// mengirim data datapegawai ke view index
		return view('index',['datapegawai' => $datapegawai]);
 
	}
}