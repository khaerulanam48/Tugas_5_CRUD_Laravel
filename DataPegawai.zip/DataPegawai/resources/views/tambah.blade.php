<!DOCTYPE html>
<html>
<head>
	<title>Tambah Data Pegawai</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>
<body>

	<div class="container">
		<div class="card">
			<div class="card-body">

				<style type="text/css">
					.pagination li{
					float: left;
					list-style-type: none;
					margin:5px;
					}
				</style>

			<h3>Tambah Data Pegawai</h3>

			</div>

			<a href="/datapegawai"> Kembali</a>
	
			<br/>
			<br/>
			<table class="table table-bordered table-striped table-hover">
			<form action="/datapegawai/store" method="post">
				{{ csrf_field() }}
				NIP <input type="text" name="nip"> <br/>
        		Nama Pegawai <input type="text" name="namapegawai"> <br/>
        		Tempat Lahir <input type="text" name="tempatlahir"> <br/>
				Alamat <textarea name="alamat"></textarea> <br/>
        		Tanggal Lahir <input type="date" name="tanggallahir"> <br/>
        		Jenis Kelamin <input type="text" name="jeniskelamin"> <br/>
        		Jabatan <input type="text" name="jabatan"> <br/>
				<br>
				<input type="submit" value="Simpan Data" onclick="return confirm('apakah anda yakin?')">
				<br/>
			
			</form>
			</table>
			<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
			<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
			<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
			</div>
		</div>
	
</body>
</html>