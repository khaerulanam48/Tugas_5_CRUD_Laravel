<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//route CRUD
Route::get('/datapegawai','DataPegawaiController@index');
Route::get('/datapegawai/tambah','DataPegawaiController@tambah');
Route::post('/datapegawai/store','DataPegawaiController@store');
Route::get('/datapegawai/edit/{id}','DataPegawaiController@edit');
Route::post('/datapegawai/update','DataPegawaiController@update');
Route::get('/datapegawai/hapus/{id}','DataPegawaiController@hapus');
Route::get('/datapegawai/cari','DataPegawaiController@cari');
